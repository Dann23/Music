import Vue from 'vue'
import Router from 'vue-router'
import Clients from '@/components/clients/Clients'
import Client from '@/components/clients/Client'
import Home from '@/components/Home'
import NewClient from '@/components/clients/NewClient'
import PasswordOptions from '@/components/clients/PasswordOptions'
import ExportResubmits from '@/components/resubmits/ExportResubmits'
import ImportResubmits from '@/components/resubmits/ImportResubmits'
import MessagingReport from '@/components/reports/MessagingReport'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home,
      meta: {
        title: 'Home'
      }
    },
    {
      path: '/clients',
      name: 'Clients',
      component: Clients,
      meta: {
        title: 'Clients'
      }
    },
    {
      path: '/client/:id',
      name: 'Client',
      component: Client,
      meta: {
        title: 'Client Details'
      }
    },
    {
      path: '/clients/new',
      name: 'NewClient',
      component: NewClient,
      meta: {
        title: 'New Client'
      }
    },
    {
      path: '/clients/:id/password',
      name: 'PasswordOptions',
      component: PasswordOptions,
      meta: {
        title: 'Password Options'
      }
    },
    {
      path: '/resubmits/export',
      name: 'ExportResubmits',
      component: ExportResubmits,
      meta: {
        title: 'ExportResubmits'
      }
    },
    {
      path: '/resubmits/import',
      name: 'ImportResubmits',
      component: ImportResubmits,
      meta: {
        title: 'ImportResubmits'
      }
    },
    {
      path: '/reports/messaging',
      name: 'MessagingReport',
      component: MessagingReport,
      meta: {
        title: 'MessagingReport'
      }
    }
  ] //,
  // mode: 'history'
})
