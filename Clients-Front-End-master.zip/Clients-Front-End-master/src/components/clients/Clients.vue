<template>
    <div class="container">
        <h4><strong>All Clients</strong></h4>
        <hr/>
        <div v-if="hasError">
            <b-alert show variant="danger">{{ error }}</b-alert>
            <b-button @click="onErrorClick" variant="primary">Reload</b-button>
        </div>
        <div v-if="!hasError && clients !== null">
            <b-table hover :sort-by.sync="sortBy" :sort-desc.sync="sortDesc" :fields="fields" :items="clients">
                <template slot="options" slot-scope="row">
                    <!-- we use @click.stop here to prevent emitting of a 'row-clicked' event  -->
                    <div class="btn-group">
                        <b-button size="sm" variant="outline-primary" @click.stop="onClickEdit(row)" class="mr-1">Edit
                        </b-button>
                        <b-button size="sm" variant="outline-success" @click.stop="onClickGo(row)" class="mr-1">Go
                        </b-button>
                    </div>
                </template>
            </b-table>
        </div>
    </div>
</template>

<script>

	export default {
		name: 'Home',
		data() {
			return {
				sortBy: 'id',
				sortDesc: false,
				fields: [
					{key: 'id', label: 'ID', sortable: true},
					{key: 'url', label: 'URL', sortable: true},
					{key: 'company_identifier', label: 'Company ID', sortable: true},
					{key: 'company_name', label: 'Name', sortable: true},
					{key: 'is_deleted', label: 'Deactivated', sortable: true},
					{key: 'options', label: 'Options', sortable: false}
				],
				clients: null,
				error: 'Unable to load clients.',
				hasError: false
			};
		},
		mounted() {
			let config = {
				headers: {
					'X-API-Key': '9c48572c-db23-4a9b-883d-a903310290e3'
				}
			};

			this.axios
				.get('https://clients.healthclub.systems/clients/all', config)
				.then(response => {
					let clients = Object.values(response);
					if (clients.length === 0) {
						this.error = 'Unable to load clients.';
						this.hasError = true;
						return;
					}

					this.clients = clients[0];
					this.hasError = false;
				})
				.catch(err => {
					this.error = err.toString();
					this.hasError = true;
				});
		},
		methods: {
			/**
			 * Called when the Edit button is clicked.
			 * @param record
			 */
			onClickEdit(record) {
				let id = record.item.id;
				this.$router.push({path: `/client/${id}`});
			},
            /**
             * Called when the Go button is clicked.
             * @param record
             */
			onClickGo(record) {
				let url = record.item.url + `/php/logincs2.php?id=` + record.item.company_identifier;

				let config = {
					headers: {
						'HTTP_JSON_KEY': 't1ibb19rgqcvbxwk2wh8t0tk6u59vo8zkynxq6s4ll8k1l77ffx4htpziz1bd2bl'
					}
				};

				this.axios
					.post(url, config)
					.then(response => {
						let url = record.item.url + `/php/home.php`;
						window.open(url, '_blank');
					})
					.catch(err => {
                        alert('Unable to Log In');
					});
			},
			/**
			 * Called when the error is clicked.
			 */
			onErrorClick() {
				this.$router.go();
			}
		}
	};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

    tr:hover {
        cursor: pointer;
    }

    .sortable tr:hover {
        cursor: pointer;
    }

    .pointer {
        cursor: pointer;
    }

    table {
        max-width: 100%;
        overflow: scroll;
    }

</style>
