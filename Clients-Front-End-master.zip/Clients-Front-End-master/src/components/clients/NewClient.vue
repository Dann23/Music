<template>
    <div class="container">
        <div v-if="hasError">
            <b-alert show variant="danger">{{ error }}</b-alert>
            <b-button @click="onErrorClick" variant="primary">Continue</b-button>
        </div>
        <b-form @submit="onSubmit" v-if="!hasError">
            <h4><strong>Login Info</strong></h4>
            <hr/>

            <b-form-group label="Username:"
                          label-for="clientIdInput"
                          description="The client's username.">
                <b-form-input id="clientIdInput"
                              v-model="username"
                              required
                              placeholder="Client ID">
                </b-form-input>
            </b-form-group>

            <b-form-group label="Password:"
                          label-for="passwordInput"
                          description="The client's password.">
                <b-form-input id="passwordInput"
                              type="password"
                              v-model="password"
                              placeholder="Password">
                </b-form-input>
            </b-form-group>

            <h4><strong>Options</strong></h4>
            <hr/>

            <b-form-group v-if="urls" label="URL:"
                          label-for="urlInput"
                          description="The URL this client goes to to log in.">
                <b-form-select id="urlInput"
                              v-model="url"
                              required
                              placeholder="URL">
                    <option v-for="option in urls" v-bind:value="option">
                        {{ option }}
                    </option>
                </b-form-select>
            </b-form-group>

            <b-form-group label="Company ID:"
                          label-for="companyIdInput"
                          description="The Company ID is a 2 digit alpha-numeric identifier unique to this client.">
                <b-form-input id="companyIdInput"
                              v-model="companyIdentifier"
                              required
                              placeholder="Company ID">
                </b-form-input>
            </b-form-group>

            <b-form-group label="Company Name:"
                          label-for="companyNameInput"
                          description="The name for this client.">
                <b-form-input id="companyNameInput"
                              v-model="companyName"
                              required
                              placeholder="Company Name">
                </b-form-input>
            </b-form-group>

            <b-button type="submit" variant="primary">Create</b-button>
        </b-form>
    </div>
</template>

<script>
export default {
  name: 'NewClient',
  data () {
    return {
      urls: [],
      client: null,
      error: 'Unable to create client.',
      hasError: false,
      username: null,
      password: null,
      url: null,
      companyIdentifier: null,
      companyName: null
    }
  },
  mounted () {
    let config = {
      headers: {
        'X-API-Key': '9c48572c-db23-4a9b-883d-a903310290e3'
      }
    }

    this.axios
      .get('https://clients.healthclub.systems/urls', config)
      .then(response => {
        let urls = Object.values(response.data)
        if (urls.length === 0) {
          this.error = 'Unable to load urls.'
          this.hasError = true
          return
        }

        this.hasError = false
        this.urls = urls
      })
      .catch(err => {
        this.error = err.toString()
        this.hasError = true
      })
  },
  methods: {
    /**
     * Called when the form is submitted.
     * @param evt
     */
    onSubmit (evt) {
      evt.preventDefault()

      let body = {
        'username': this.username,
        'password': this.password,
        'url': this.url,
        'company_identifier': this.companyIdentifier,
        'company_name': this.companyName
      }

      let config = {
        headers: {
          'X-API-Key': '9c48572c-db23-4a9b-883d-a903310290e3'
        }
      }

      this.axios
        .post(`https://clients.healthclub.systems/clients`, body, config)
        .then(response => {
          this.$router.push('/')
        })
        .catch(err => {
          this.client = null
          this.error = err.response.data
          this.hasError = true
        })
    },
    /**
     * Called when the error is clicked.
     */
    onErrorClick () {
      this.$router.go()
    }
  }
}
</script>

<style scoped>
    form {
        margin: 3em 0;
    }

    h4 {
        margin-top: 2em;
    }

    button {
        margin-top: 2em;
    }
</style>
