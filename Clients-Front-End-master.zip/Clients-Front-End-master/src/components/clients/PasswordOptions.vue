<template>
    <div class="container">
        <div v-if="hasError">
            <b-alert show variant="danger">{{ error }}</b-alert>
            <b-button @click="onErrorClick" variant="primary">Continue</b-button>
        </div>
        <b-form id="form" v-if="!hasError && client !== null">
            <h4><strong>{{ `Password Options for ${client.company_name || 'Unknown'}` }}</strong></h4>
            <hr/>

            <b-form-group label-for="passwordInput">
                <b-form-input id="passwordInput"
                              type="text"
                              required
                              @keyup.native="clearMessage"
                              v-model="password"
                              aria-describedby="passwordInputLiveFeedback"
                              :state="validPasswordState"
                              placeholder="Password">
                </b-form-input>
                <b-form-invalid-feedback id="passwordInputLiveFeedback">
                    Password is required.
                </b-form-invalid-feedback>
            </b-form-group>

            <b-alert :variant="alertStyle"
                     dismissible
                     fade
                     :show="hasMessage"
                     @dismissed="hasMessage=false">
                {{ message }}
            </b-alert>

            <div>
                <b-form-group label-for="verifyPasswordButton"
                              description="This will tell you if the password you entered above matches the client's customer password.">
                    <b-button :disabled="!validPasswordState" id="verifyPasswordButton" @click="onClickVerifyPassword()" variant="warning">Verify Password</b-button>
                </b-form-group>

                <b-form-group :state="validPasswordState" label-for="changePasswordButton"
                              description="Warning: This will permanently change the client's customer password.">
                    <b-button :disabled="!validPasswordState" id="changePasswordButton" @click="onClickChangePassword()" variant="danger">Change Password</b-button>
                </b-form-group>
            </div>

        </b-form>
    </div>
</template>

<script>
export default {
  name: 'PasswordOptions',
  data () {
    return {
      client: null,
      error: 'Unable to create client.',
      hasError: false,
      username: '',
      password: '',
      id: null,
      hasMessage: false,
      message: null,
      alertStyle: 'success'
    }
  },
  mounted () {
    // Get the ID.
    let id = parseInt(this.$route.params.id) || null

    // If invalid, go to home.
    if (!id || id === null) {
      this.$router.push('/')
      return
    }

    this.id = id

    let config = {
      headers: {
        'X-API-Key': '9c48572c-db23-4a9b-883d-a903310290e3'
      }
    }

    // Get the client.
    this.axios
      .post(`https://clients.healthclub.systems/clients/${id}/verify?showDeleted=true`, null, config)
      .then(response => {
        // Store response.
        this.hasError = false
        this.client = response.data
        this.username = this.client.username || ''

        // If the client is deleted, then can't show this screen.
        if (this.client.is_deleted || false) {
          this.error = 'Password options are unavailable for deleted clients.'
          this.hasError = true
        }
      })
      .catch(err => {
        this.error = err.toString()
        this.hasError = true
      })
  },
  computed: {
    validPasswordState () {
      return this.password.length > 0
    }
  },
  methods: {
    /**
     * Called when the user taps the change password button.
     */
    onClickChangePassword () {
      this.hasMessage = false
      if (this.password.length === 0) {
        return
      }

      let body = {
        'username': this.username,
        'password': this.password
      }

      let config = {
        headers: {
          'X-API-Key': '9c48572c-db23-4a9b-883d-a903310290e3'
        }
      }

      this.axios
        .put(`https://clients.healthclub.systems/clients/${this.id}/password_reset`, body, config)
        .then(response => {
          this.$router.push('/')
        })
        .catch(err => {
          this.error = err.response.data
          this.hasError = true
        })
    },
    /**
     * Called when the user taps the verify password button.
     */
    onClickVerifyPassword () {
      this.hasMessage = false
      if (this.password.length === 0) {
        return
      }

      let body = {
        'username': this.username,
        'password': this.password
      }

      let config = {
        headers: {
          'X-API-Key': '9c48572c-db23-4a9b-883d-a903310290e3'
        }
      }

      this.axios
        .post(`https://clients.healthclub.systems/verify`, body, config)
        .then(response => {
          this.message = 'Credentials are valid.'
          this.alertStyle = 'success'
          this.hasMessage = true
        })
        .catch(err => {
          if (err.response.status && err.response.status === 404) {
            this.message = 'The password you entered does not match the one on file for this client.'
          } else {
            this.message = err.response.data
          }

          this.alertStyle = 'danger'
          this.hasMessage = true
        })
    },
    /**
     * Called when the user taps the error button.
     */
    onErrorClick () {
      if (this.client.is_deleted || false) {
        this.$router.push('/')
      } else {
        this.$router.go()
      }
    },
    /**
     * Clears the message.
     */
    clearMessage () {
      this.hasMessage = false
    }
  }
}
</script>

<style scoped>
    form {
        margin: 3em 0;
    }

    h4 {
        margin-top: 2em;
    }

    button {
        margin-top: 2em;
    }
</style>
