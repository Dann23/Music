<template>
    <div class="container">
        <div v-if="hasError">
            <b-alert show variant="danger">{{ error }}</b-alert>
            <b-button @click="onErrorClick" variant="primary">Continue</b-button>
        </div>
        <b-form @submit="onSubmit" v-if="!hasError && client !== null">
            <h4><strong>Client Info</strong></h4>
            <hr/>
            <b-form-group label="ID:"
                          label-for="idInput"
                          description="The ID cannot be changed.">
                <b-form-input id="idInput"
                              type="email"
                              v-model="client.id"
                              disabled
                              placeholder="ID">
                </b-form-input>
            </b-form-group>

            <b-form-group v-if="urls" label="URL:"
                          label-for="urlInput"
                          description="The URL this client goes to for accessing the Club Systems software.">
                <b-form-select id="urlInput"
                               v-model="client.url"
                               required
                               placeholder="URL">
                    <option v-for="option in urls" v-bind:value="option">
                        {{ option }}
                    </option>
                </b-form-select>
            </b-form-group>

            <b-form-group label="Client Username:"
                          label-for="clientIdInput"
                          description="The client's login username.">
                <b-form-input id="clientIdInput"
                              v-model="client.username"
                              required
                              placeholder="Client ID">
                </b-form-input>
            </b-form-group>

            <b-form-group label="Company ID:"
                          label-for="companyIdInput"
                          description="The Company ID is a 2 digit alpha-numeric identifier unique to this client.">
                <b-form-input id="companyIdInput"
                              v-model="client.company_identifier"
                              required
                              placeholder="Company ID">
                </b-form-input>
            </b-form-group>

            <b-form-group label="Company Name:"
                          label-for="companyNameInput"
                          description="The name for this client.">
                <b-form-input id="companyNameInput"
                              v-model="client.company_name"
                              required
                              placeholder="Company Name">
                </b-form-input>
            </b-form-group>

            <h4><strong>Sub IDs</strong></h4>
            <b-form-text>Sub IDs are used for payment processing for large clubs.</b-form-text>
            <hr/>

            <b-alert show variant="danger" v-if="newSubIdError !== ''" dismissable>{{ newSubIdError }}</b-alert>

            <b-input-group label-for="subIdsInput">
                <b-form-input id="subIdsInput" v-model="newSubId" placeholder="Enter new Sub ID">
                </b-form-input>
                <b-input-group-append>
                    <b-btn class="btn-success" @click.stop="onAddNewSubId()">Add</b-btn>
                </b-input-group-append>

                <b-table striped hover :sort-by.sync="sortBy" :sort-desc.sync="sortDesc" :fields="fields" :items="newSubIds" v-if="newSubIds.length > 0">
                    <template slot="delete" slot-scope="row">
                        <b-button size="sm" variant="outline-danger" @click.stop="onClickTableRow(row)" class="mr-2">Delete</b-button>
                    </template>
                </b-table>
            </b-input-group>

            <b-alert show variant="secondary" class="noSubIdsAlert" v-if="newSubIds.length === 0">No Sub IDs</b-alert>

            <h4><strong>Options</strong></h4>
            <hr/>
            <b-form-group label-for="deletedCheckboxGroup"
                          description="When this checkbox is checked, the client will NOT be able to log in to the Club Systems software.">
                <b-form-checkbox-group v-model="client.is_deleted" id="deletedCheckboxGroup">
                    <b-form-checkbox>Disable login access</b-form-checkbox>
                </b-form-checkbox-group>
            </b-form-group>

            <b-button type="submit" variant="primary">Save Changes</b-button>
            <b-button @click="onClickPasswordOptions" variant="outline-danger">Password Options</b-button>
        </b-form>
    </div>
</template>

<script>
export default {
  name: 'Client',
  data () {
    return {
      client: null,
      error: 'Unable to load client details.',
      hasError: false,
      id: null,
      urls: [],
      newSubId: '',
      newSubIds: [],
      newSubIdError: '',
      sortBy: 'SubId',
      sortDesc: false,
      fields: [
        { key: 'SubId', sortable: false },
        { key: 'delete', sortable: false }
      ]
    }
  },
  mounted () {
    // Get the ID.
    let id = parseInt(this.$route.params.id) || null

    // Validate ID.
    if (!id || id === null) {
      this.$router.push('/')
      return
    }
    this.id = id

    let config = {
      headers: {
        'X-API-Key': '9c48572c-db23-4a9b-883d-a903310290e3'
      }
    }

    // Get the client info.
    this.axios
      .post(`https://clients.healthclub.systems/clients/${id}/verify?showDeleted=true`, null, config)
      .then(response => {
        let client = response.data

        this.hasError = false
        this.client = client
        if (Array.isArray(this.client.sub_ids)) {
          for (let i = 0; i < this.client.sub_ids.length; i++) {
            this.newSubIds.push({
              'SubId': this.client.sub_ids[i]
            })
          }
        }

        this.urls.push(client.url)

        // Load the Club Systems URLs.
        this.loadUrls()
      })
      .catch(err => {
        this.client = null
        this.error = err.toString()
        this.hasError = true
      })
  },
  methods: {
    /**
     * Loads the URLs from Club Systems.
     */
    loadUrls () {
      let config = {
        headers: {
          'X-API-Key': '9c48572c-db23-4a9b-883d-a903310290e3'
        }
      }

      this.axios
        .get('https://clients.healthclub.systems/urls', config)
        .then(response => {
          let urls = Object.values(response.data)
          if (urls.length === 0) {
            this.error = 'Unable to load urls.'
            this.hasError = true
            return
          }

          this.hasError = false
          this.urls = urls
        })
        .catch(err => {
          this.error = err.toString()
          this.hasError = true
        })
    },
    /**
     * Form submit.
     * @param evt
     */
    onSubmit (evt) {
      // Validate the form.
      evt.preventDefault()

      // JSON.stringify(this.form)
      let body = {
        'username': this.client.username,
        'url': this.client.url,
        'company_identifier': this.client.company_identifier,
        'company_name': this.client.company_name,
        'sub_ids': this.newSubIds.map(function (item) { return item.SubId }),
        'is_deleted': Boolean(this.client.is_deleted)
      }

      let config = {
        headers: {
          'X-API-Key': '9c48572c-db23-4a9b-883d-a903310290e3'
        }
      }

      this.axios
        .put(`https://clients.healthclub.systems/clients/${this.client.id}`, body, config)
        .then(response => {
          this.$router.push('/')
        })
        .catch(err => {
          this.client = null
          this.error = err.response.data
          this.hasError = true
        })
    },
    /**
     * Called when the error is clicked.
     */
    onErrorClick () {
      this.$router.go()
    },
    /**
     * Called when password options are selected.
     */
    onClickPasswordOptions () {
      this.$router.push(`/clients/${this.id}/password`)
    },
    /**
     * Called when an item in the table is clicked.
     * @param row
     */
    onClickTableRow (row) {
      this.newSubIds = this.newSubIds.filter(item => { return item.SubId !== row.item.SubId })
    },
    /**
     * Called when the add button is pressed.
     * @param e
     */
    onAddNewSubId (e) {
      if (this.newSubId.length !== 2) {
        this.newSubIdError = 'Must be 2 characters in length.'
        return
      }

      if (this.newSubId.match(/^[A-Z0-9]{2}$/i) === null) {
        this.newSubIdError = 'Must be alphanumeric.'
        return
      }

      this.newSubIdError = ''
      this.newSubIds.push({
        'SubId': this.newSubId.toUpperCase()
      })
      this.newSubId = ''
    }
  }
}
</script>

<style scoped>
    form {
        margin: 3em 0;
    }

    h4 {
        margin-top: 2em;
    }

    table {
        margin-top: 2em;
    }

    .noSubIdsAlert {
        margin-top: 1em;
    }

</style>
