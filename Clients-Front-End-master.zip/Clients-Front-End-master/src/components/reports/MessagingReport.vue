<template>
    <div class="container">
        <h4><strong>2-Way Messaging Usage Report</strong></h4>
        <hr/>

        <b-form id="form">

            <div class="form-group row">

                <div class="col-md-6" >
                    <label for="fromInput">From:</label>
                    <datepicker :value="from"
                                id="fromInput"
                                size="sm"
                                :use-utc=true
                                :bootstrap-styling=true
                                @input="onFromDateChanged"
                                format="yyyy-MM-dd">
                    </datepicker>
                </div>

                <div class="col-md-6" >
                    <label for="toInput">To:</label>
                    <datepicker :value="to"
                                id="toInput"
                                size="sm"
                                :use-utc=true
                                :bootstrap-styling=true
                                @input="onToDateChanged"
                                format="yyyy-MM-dd">
                    </datepicker>
                </div>

                <b-form-text id="timezoneText">All dates are in UTC format.</b-form-text>
            </div>

        </b-form>

        <b-alert :show="typeof errorMessage === 'string'" dismissible @dismissed="onErrorClick" variant="danger">{{ errorMessage }}</b-alert>

        <b-table striped hover v-if="records !== null" :sort-by.sync="sortBy" :sort-desc.sync="sortDesc"
                 :fields="fields" :items="records">
            <template slot="options" slot-scope="row">
                <b-button size="sm" variant="outline-primary" @click.stop="onClickTableRow(row)" class="mr-2">Show
                    Client
                </b-button>
            </template>
        </b-table>

    </div>
</template>

<script>
	import moment from 'moment';
	import Datepicker from 'vuejs-datepicker';

	export default {
		name: 'MessagingReport',
		components: {
			Datepicker
		},
		data() {
			return {
                errorMessage: null,
				from: new Date(),
				to: new Date(),
				records: null,

				sortBy: 'id',
				sortDesc: false,
				fields: [
					{key: 'customer', label: 'Client Name', sortable: true},
					{key: 'twilio_cost', label: 'CS Cost', sortable: true},
					{key: 'amount_due', label: 'Charge Amount', sortable: true},
					{key: 'options', label: 'Options', sortable: false}
				]
			};
		},
		mounted() {
			this.from = moment().add(-1, 'month').format('YYYY-MM-DD');
			this.to = moment().format('YYYY-MM-DD');
			this.onClickSubmitButton()
		},
		methods: {
			/**
			 * Called when the user taps the submit button.
			 */
			onClickSubmitButton() {

				let config = {
					headers: {
						'x-api-key': 'b4280a3bb99b456caff9ca6c98ad7add'
					}
				};

				let data = {
					from: moment(this.from).format('YYYY-MM-DD') + ' 00:00:00',
					to: moment(this.to).format('YYYY-MM-DD') + ' 00:00:00'
				};

				this.records = null;
				this.errorMessage = null;

				// Get the client.
				this.axios
					.post(`https://sms.clubsys.io/reports/messages`, data, config)
					.then(response => {

						if (!response.data.data) {
							this.records = null;
							this.errorMessage = "No results found for the specified date range.";
							return;
						}

						this.errorMessage = null;
						this.records = response.data.data;
					})
					.catch(err => {
						this.records = null;
						this.errorMessage = `Oops, that didn't work.`
						console.log(err);
					});
			},
			/**
			 * Called when the user taps the error button.
			 */
			onErrorClick() {
				this.errorMessage = null;
			},
			/**
			 * Called when an item in the table is clicked.
			 * @param record
			 */
			onClickTableRow(record) {
				let id = record.item.client_identifier;
				this.$router.push({path: `/client/${id}`});
			},
			/**
             * Called when the from date is changed.
			 * @param date
			 */
			onFromDateChanged(date) {
				this.from = moment(date).utc().format('YYYY-MM-DD')
                this.onClickSubmitButton()
            },
			/**
			 * Called when the to date is changed.
			 * @param date
			 */
            onToDateChanged(date) {
				this.to = moment(date).utc().format('YYYY-MM-DD')
				this.onClickSubmitButton()
            }
		}
	};
</script>

<style scoped>

    h4 {
        margin-top: 2em;
    }

    table {
        margin-top: 2em;
    }

    #timezoneText {
        margin: 1em 1em 0 1em;
    }

</style>
