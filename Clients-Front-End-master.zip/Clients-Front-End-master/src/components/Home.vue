<template>
    <div class="container">
        <h4><strong>Dashboard</strong></h4>
        <h6>Version <b-badge variant="info">{{ version }}</b-badge></h6>
        <hr/>
        <b-alert variant="success" show>You're logged in.</b-alert>
    </div>
</template>

<script>
export default {
  name: 'Home',
  computed: {
    version () {
      return require('./../../package.json').version
    }
  }
}
</script>

<style scoped>

</style>
