<template>
    <div class="container">

        <h4 class="mt-5"><strong>Export Resubmits</strong></h4>
        <hr/>

        <b-form id="form" class="mt-3">
            <div>
                <b-form-group label="Number of days:" label-for="daysInput" class="mb-5">
                    <b-form-input id="daysInput"
                                  type="text"
                                  required
                                  v-model="numberOfDays"
                                  aria-describedby="daysInputLiveFeedback"
                                  :state="isValidNumber"
                                  placeholder="Number of days">
                    </b-form-input>
                    <b-form-invalid-feedback id="daysInputLiveFeedback">
                        Please enter the number of days (1 to 365).
                    </b-form-invalid-feedback>
                </b-form-group>

                <div>
                    <b-form-group label-for="exportButton"
                                  :description="resubmitsDescription">
                        <b-button :disabled="isRunningResubmits" id="exportButton" @click="onClickExportResubmits()"
                                  variant="primary">{{ exportButtonTitle }}
                        </b-button>
                    </b-form-group>
                </div>
            </div>
        </b-form>

        <h4 class="mt-5"><strong>Resubmit Jobs</strong></h4>
        <hr/>
        <div class="mb-3">
            <b-button size="sm" variant="primary" :disabled="isRunningResubmits" @click.stop="loadAllResubmits">{{
                refreshButtonTitle }}
            </b-button>
        </div>
        <div>
            <div v-if="typeof error === 'string'">
                <b-alert variant="danger" show>{{ error }}</b-alert>
            </div>
            <div v-else>
                <b-table v-if="statuses.length > 0" striped hover :sort-by.sync="sortBy" :sort-desc.sync="sortDesc" :fields="fields"
                         :items="statuses">
                    <template slot="status" slot-scope="data">
                        <b-badge variant="primary" v-if="data.value === 'running'">{{ data.value }}</b-badge>
                        <b-badge variant="success" v-else-if="data.value === 'finished'">{{ data.value }}</b-badge>
                        <b-badge variant="danger" v-else-if="data.value === 'error'">{{ data.value }}</b-badge>
                        <b-badge variant="secondary" v-else>{{ data.value }}</b-badge>
                    </template>
                    <template slot="options" slot-scope="row">
                        <b-button v-if="row.item.status === 'finished'" size="sm" variant="outline-primary" @click.stop="onClickShowFileButton(row)"
                                      class="mr-2">Download</b-button>
                        <b-button v-if="row.item.status === 'error'" size="sm" variant="outline-secondary" @click.stop="onShowErrorDetails(row)"
                                  class="mr-2">Details</b-button>
                        <b-button v-if="row.item.status !== 'running' && row.item.status !== 'pending'" size="sm" variant="outline-danger" @click.stop="onClickDeleteButton(row)"
                                      class="mr-2">Delete</b-button>
                    </template>
                </b-table>
                <div v-else>
                    <b-alert variant="warning" show>No jobs.</b-alert>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'

// The common API headers.
const config = {
  headers: {
    'X-API-Key': '7925eeb5-fbe9-4bfd-bb1b-8fa946a4ebe9'
  }
}

// The API base URL.
// If ENV == 'development', use: `http://localhost:8080`.
const apiUrl = 'https://resubmits.healthclubsystems.com'

export default {
  name: 'ExportResubmits',
  data () {
    return {
      isRunningResubmits: false,
      numberOfDays: 30,
      statuses: [],
      error: null,
      sortBy: 'id',
      sortDesc: true,
      fields: [
        {key: 'id', label: 'ID', sortable: true},
        {key: 'days', label: 'Days', sortable: true},
        {key: 'processor', label: 'Processor', sortable: true},
        {key: 'status', label: 'Status', sortable: true},
        {key: 'created_at', label: 'Created', sortable: true},
        {key: 'updated_at', label: 'Updated', sortable: true},
        {key: 'options', label: 'Options', sortable: false}
      ]
    }
  },
  computed: {
    resubmitsDescription () {
      return this.isRunningResubmits ? 'This operation might take a while.' : 'This will export the resubmits for the number of days you specify above.'
    },
    isValidNumber () {
      let value = parseInt(this.numberOfDays)
      return typeof value === 'number' && this.numberOfDays > 0 && this.numberOfDays <= 365
    },
    exportButtonTitle () {
      return this.isRunningResubmits ? 'Please wait...' : 'Export'
    },
    refreshButtonTitle () {
      return this.isRunningResubmits ? 'Refreshing...' : 'Refresh'
    }
  },
  mounted () {
    this.loadAllResubmits()
  },
  methods: {
    /**
       * Fetches all resubmit tasks.
       */
    loadAllResubmits () {
      // Clear error
      this.error = null

      this.axios
        .get(`${apiUrl}/tasks`, config)
        .then(response => {
          let statuses = response.data.data
          statuses.map(status => {
            status.days = status.input.days
            status.processor = status.input.processor === 'tSys' ? 'T' : 'FA/CNX'
            status.created_at = moment(status.created_at).fromNow()
            status.updated_at = moment(status.updated_at).fromNow()
          })
          this.statuses = statuses
        })
        .catch(err => {
          console.log(err)
          const defaultError = 'Unable to load data. Please try again later.'
          if (err.response && err.response.data && err.response.data.message) {
            this.error = err.response.data.message || defaultError
          } else {
            this.error = defaultError
          }
        })
    },
    /**
       * Called when the user selects the export button.
       */
    onClickExportResubmits () {
      this.isRunningResubmits = true

      let body = {
        'days': parseInt(this.numberOfDays)
      }

      this.error = null

      this.axios
        .post(`${apiUrl}/export`, body, config)
        .then(response => {
          this.loadAllResubmits()
          this.isRunningResubmits = false
        })
        .catch(err => {
          console.log(err)
          const defaultError = 'Unable to export data. Please try again later.'
          if (err.response && err.response.data && err.response.data.message) {
            this.error = err.response.data.message || defaultError
          } else {
            this.error = defaultError
          }
          this.isRunningResubmits = false
        })
    },
    /**
       * Called when the show file button is pressed.
       */
    onClickShowFileButton (record) {
      let filename = record.item.output.filename || ''

      if (filename.length > 0) {
        window.open(`${apiUrl}/public/${filename}`, '_blank')
      }
    },
    /**
     * Shows the error details.
     */
    onShowErrorDetails (record) {
        alert(JSON.stringify(record.item.output))
    },
    /**
       * Called when the delete button is pressed.
       * @param record
       */
    onClickDeleteButton (record) {
      // Confirm delete.
      if (!confirm(`Are you sure you want to delete job #${record.item.id}?`)) {
        return
      }

      this.error = null

      // Remove from records.
      this.statuses = this.statuses.filter(status => {
        return status.id !== record.item.id
      })

      // Delete on server.
      this.axios
        .delete(`${apiUrl}/tasks/${record.item.id}`, config)
        .then(response => {
        }).catch(e => {
          console.log(e)
        })
    }
  }
}
</script>

<style scoped>

</style>
