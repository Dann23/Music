<template>
    <div class="container">
        <h4><strong>Import Resubmits</strong></h4>
        <hr/>
        <div v-if="!file && successMessage === null">
            <b-form-file v-model="file" :state="Boolean(file)" placeholder="Choose a Resubmits file..."
                         ref="fileInput"></b-form-file>
            <b-alert variant="warning" show class="mt-3">Must be a CSV file. The file's header row must match <span class="text-monospace">valtrans</span> column structure.</b-alert>
        </div>
        <div v-if="file">
            <b-card header="Selected File"
                    style="max-width: 20rem;"
                    class="mt-5 mb-5">
                <div v-if="file.type === 'text/csv'">
                    <p class="card-text">
                        {{ file && file.name }}
                        <b-badge pill variant="success">{{ file.type }}</b-badge>
                    </p>
                    <b-button size="sm" variant="primary" @click="uploadFile()">Import</b-button>
                    <b-button size="sm" variant="danger" @click="clearFile()">Remove</b-button>
                </div>
                <div v-else>
                    <p class="card-text">
                        {{ file && file.name }}
                    </p>
                    <p>
                        Invalid file type:
                        <b-badge pill variant="warning">{{ file.type }}</b-badge>
                    </p>
                    <b-button size="sm" variant="danger" @click="clearFile()">Remove</b-button>
                </div>
            </b-card>
        </div>
        <div v-if="typeof successMessage === 'string'">
            <b-alert variant="success" show>{{ successMessage }}</b-alert>
        </div>
        <div v-else-if="typeof errorMessage === 'string'">
            <b-alert variant="danger" show dismissible @dismissed="onDismissErrorAlert()">{{ errorMessage }}</b-alert>
        </div>
    </div>
</template>

<script>

// The common API headers.
const config = {
  headers: {
    'X-API-Key': '7925eeb5-fbe9-4bfd-bb1b-8fa946a4ebe9',
    'Content-Type': 'multipart/form-data'
  }
}

// The API base URL.
const apiUrl = 'https://resubmits.healthclubsystems.com'

export default {
  name: 'ImportResubmits',
  data () {
    return {
      file: null,
      successMessage: null,
      errorMessage: null
    }
  },
  methods: {
    /**
     * Uploads the file.
     */
    uploadFile () {
      if (!confirm('Are you sure you want to import the selected file across all Club Systems servers? This action cannot be undone.')) return

      this.successMessage = null
      this.errorMessage = null

      let formData = new FormData()
      formData.append('file', this.file)

      // Send to resubmits API.
      this.axios
        .post(`${apiUrl}/import`, formData, config)
        .then(response => {
          this.successMessage = response.data.message
          this.file = null
        })
        .catch(err => {
          const defaultError = 'Unable to load data. Please try again later.'
          if (err.response && err.response.data && err.response.data.message) {
            this.errorMessage = err.response.data.message || defaultError
          } else {
            this.errorMessage = defaultError
          }
        })
    },
    /**
     * Clears the selected file.
     */
    clearFile () {
      if (this.$refs.fileInput) {
        this.$refs.fileInput.reset()
      }
      this.file = null
    },
    /**
     * Called when the error alert is dismissed.
     */
    onDismissErrorAlert () {
      this.errorMessage = null
      this.successMessage = null
    }
  }
}
</script>
<style scoped>


</style>
