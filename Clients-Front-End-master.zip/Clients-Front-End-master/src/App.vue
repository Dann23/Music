<template>
  <div id="app">
    <b-navbar id="navBar" toggleable="md" :sticky="sticky" type="light" variant="light">
      <b-navbar-toggle target="nav_collapse"></b-navbar-toggle>
      <b-navbar-brand href="/">CS Admin</b-navbar-brand>
      <b-collapse is-nav id="nav_collapse">
        <b-navbar-nav>
          <b-nav-item-dropdown text="Clients" left>
            <b-nav-item><router-link class="nav-link" to="/clients">All Clients</router-link></b-nav-item>
            <b-nav-item><router-link class="nav-link" to="/clients/new">New Client</router-link></b-nav-item>
          </b-nav-item-dropdown>

          <b-nav-item-dropdown text="Resubmits" left>
            <b-nav-item><router-link class="nav-link" to="/resubmits/export">Export</router-link></b-nav-item>
            <b-nav-item><router-link class="nav-link" to="/resubmits/import">Import</router-link></b-nav-item>
          </b-nav-item-dropdown>

          <b-nav-item-dropdown text="Reports" left>
            <b-nav-item><router-link class="nav-link" to="/reports/messaging">2-Way Messaging Usage</router-link></b-nav-item>
          </b-nav-item-dropdown>
        </b-navbar-nav>
        <b-navbar-nav class="ml-auto">
          <b-nav-item class="nav-link" href="/oauth2/sign_out">Sign Out</b-nav-item>
        </b-navbar-nav>
      </b-collapse>
    </b-navbar>
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {
      sticky: true
    }
  }
}
</script>

<style>
  #navBar {
    margin-bottom: 1em;
  }
</style>
